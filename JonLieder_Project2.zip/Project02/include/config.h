#ifndef INCLUDE_H
#define INCLUDE_H

#define ROWS 4
#define COLS 4
#define AUG_COLS (COLS + 1)

#endif
